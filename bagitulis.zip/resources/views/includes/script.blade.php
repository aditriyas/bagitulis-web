    <!-- Bootstrap core JavaScript -->
        <script src="{{asset('vendor/jquery/jquery.slim.min.js')}}"></script>
        <script src="{{asset('vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
        AOS.init();
        </script>
        <script src="{{asset('script/navbar-scroll.js')}}"></script>
