<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link href="{{asset('style/main.css')}}" rel="stylesheet" />
    <link rel="icon" type="image/png" href="{{asset('images/logo-title.svg')}}" />
