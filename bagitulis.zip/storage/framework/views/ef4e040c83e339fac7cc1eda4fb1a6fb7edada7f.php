

<?php $__env->startSection('title'); ?>
    Detail Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content page-products">
    <div class="section-success" data-aos="zoom-in">
        <div class="container">
            <div class="row align-items-center row-login justify-content-center">
                <div class="col-lg-6 text-center">
                    <a href="#">
                        <img src="<?php echo e(asset('storage/thumbnails/'.$file->thumbnail)); ?>" alt="" class="mb-4 w-100 rounded" />
                    </a>
                    <div class="products-text">
                        <?php echo e($file->title); ?>

                    </div>
                    <div class="products-price mt-2 w-100">by <?php echo e($file->author); ?></div>
                    <p class="mt-2"><?php echo e($file->description); ?></p>
                    <a href="<?php echo e(asset('storage/files/'.$file->file)); ?>" target="_blank" class="btn btn-success w-50 mt-3">Download</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/pages/details.blade.php ENDPATH**/ ?>