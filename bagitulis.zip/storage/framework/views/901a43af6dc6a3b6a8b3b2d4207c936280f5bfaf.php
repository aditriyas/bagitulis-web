<div class="border-right" id="sidebar-wrapper">
    <div class="sidebar-heading text-center">
        <img src="<?php echo e(asset('images/navbar-logo.svg')); ?>" alt="" class="my-4 w-50" />
    </div>
    
    <?php if(Auth::user()->role == 'admin'): ?>
        <div class="list-group list-group-flush">
            <a href="<?php echo e(route('home')); ?>" class="list-group-item list-group-item-action <?php echo e(Request::is('home') ? 'active' : ''); ?>">Dashboard</a>
            <a href="<?php echo e(route('admin.product.index')); ?>" class="list-group-item list-group-item-action <?php echo e(Request::is('admin/product*') ? 'active' : ''); ?>">Products</a>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="list-group-item list-group-item-action <?php echo e(Request::is('admin/users') ? 'active' : ''); ?>">Users</a>
        </div>
    <?php else: ?>
        <div class="list-group list-group-flush">
            <a href="<?php echo e(route('home')); ?>" class="list-group-item list-group-item-action <?php echo e(Request::is('home') ? 'active' : ''); ?>">My Writings</a>
            <a href="<?php echo e(route('member.product.index')); ?>" class="list-group-item list-group-item-action <?php echo e(Request::is('member/product') ? 'active' : ''); ?>">Collections</a>
            <a href="<?php echo e(route('member.product.create')); ?>" class="list-group-item list-group-item-action <?php echo e(Request::is('member/product/create') ? 'active' : ''); ?>">Create Writings</a>
        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>