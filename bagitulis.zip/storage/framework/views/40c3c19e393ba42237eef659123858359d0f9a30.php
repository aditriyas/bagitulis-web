

<?php $__env->startSection('content'); ?>
  <div id="page-content-wrapper">
    <nav class="navbar navbar-store navbar-expand-lg navbar-light fixed-top" data-aos="fade-down">
      <button class="btn btn-secondary d-md-none mr-auto mr-2" id="menu-toggle">
        &laquo; Menu
      </button>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>

    <div class="section-content section-dashboard-home" data-aos="fade-up">
      <div class="container-fluid">
        <div class="dashboard-heading">
          <h2 class="dashboard-title">Users Management</h2>
          
        </div>
        <div class="dashboard-content">
          <div class="row mt-5">
            <div class="col-lg-12">
                <table class="table table-striped" id="table-users">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->role); ?></td>
                                <td class="text-center">
                                    <button type="button" class="btn btn-warning btn-edit">Edit</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
   <!-- Modal -->
    <div class="modal fade" id="modalEdit" data-backdrop="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Users</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form action="<?php echo e(route('admin.users.update')); ?>" method="post" id="form-update">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="id">
                            <div class="form-group">
                                <input type="text"class="form-control" name="name" placeholder="Nama" required>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="Email" readonly>
                            </div>
                            <div class="form-group">
                                <select class="form-control" name="role">
                                    <option selected disabled>- role -</option>
                                    <option value='member'>Member</option>
                                    <option value='admin'>Admin</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Password</label><small class="text-muted">(Opsional)</small>
                                <input type="password" class="form-control" name="password">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btn-submit">Save changes</button>
            </div>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.25/datatables.min.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.25/datatables.min.js"></script>
    <script>
        $(document).ready(function () {
            var table = $('#table-users').DataTable();

            // get user data
            $("#table-users tbody").on('click', '.btn-edit', function () {
                var data = table.row($(this).parents('tr')).data();
                console.log(data);
                $("input[name='id']").val(data[0]);
                $("input[name='name']").val(data[1]);
                $("input[name='email']").val(data[2]);
                $("select[name='role']").val(data[3]);

                $("#modalEdit").modal('show')
            });

            $('#btn-submit').on('click', function () {
                $('#form-update').submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/pages/admin/users.blade.php ENDPATH**/ ?>