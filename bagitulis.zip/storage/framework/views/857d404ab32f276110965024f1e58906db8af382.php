    <!-- Bootstrap core JavaScript -->
        <script src="<?php echo e(asset('vendor/jquery/jquery.slim.min.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
        AOS.init();
        </script>
        <script src="<?php echo e(asset('script/navbar-scroll.js')); ?>"></script>
<?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/includes/script.blade.php ENDPATH**/ ?>