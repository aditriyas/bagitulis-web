

<?php $__env->startSection('title'); ?>
    Collection Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content page-home">
    <section class="store-new-product">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                    <h5>Writings</h5>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                        <a class="component-products d-block" href="<?php echo e(route('collection.show', ['id' => $file->id])); ?>">
                            <div class="products-thumbnail">
                                <div class="products-image" style="background-image: url('<?php echo e(asset('/storage/thumbnails/'.$file->thumbnail)); ?>');"></div>
                            </div>
                            <div class="products-text"><?php echo e($file->title); ?></div>
                            <div class="products-price">by <?php echo e($file->author); ?></div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/pages/collection.blade.php ENDPATH**/ ?>