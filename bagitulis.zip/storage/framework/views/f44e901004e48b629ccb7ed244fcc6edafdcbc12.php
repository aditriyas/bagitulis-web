

<?php $__env->startSection('title'); ?>
    Homepage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content page-home">
        <div class="section-home" data-aos="fade-up">
            <div class="container">
            <div class="row align-items-center row-home">
                <div class="col-lg-6 text-center">
                <img src="/images/home-pict.png" alt="" class="w-100 mb-4 mb-lg-none" />
                </div>
                <div class="col-lg-5 ml-5">
                <h2> Upload karya <br />tulis terbaikmu!
                </h2>
                <p>Upload karya tulismu agar dapat bermanfaat bagi orang lain</p>
                <a href="<?php echo e(url('collection')); ?>" class="btn btn-success btn-block mt-4 w-75">Lihat Karya tulis</a>
                </div>
            </div>
            </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/pages/home.blade.php ENDPATH**/ ?>