    <footer>
        <div class="container">
            <div class="row">
            <div class="col-12 text-center">
                <p class="pt-4 pb-2">
                2021 Copyright Bagitulis. All Rights Reserved <br />
                Aditya Triyaswanda
                </p>
            </div>
            </div>
        </div>
        </footer><?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/includes/footer.blade.php ENDPATH**/ ?>