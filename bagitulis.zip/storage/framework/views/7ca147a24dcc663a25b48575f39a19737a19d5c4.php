<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link href="<?php echo e(asset('style/main.css')); ?>" rel="stylesheet" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo-title.svg')); ?>" />
<?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/includes/style.blade.php ENDPATH**/ ?>