

<?php $__env->startSection('content'); ?>
  <div id="page-content-wrapper">
    <nav class="navbar navbar-store navbar-expand-lg navbar-light fixed-top" data-aos="fade-down">
      <button class="btn btn-secondary d-md-none mr-auto mr-2" id="menu-toggle">
        &laquo; Menu
      </button>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>

    <div class="section-content section-dashboard-home" data-aos="fade-up">
      <div class="container-fluid">
        <div class="dashboard-heading">
          <h2 class="dashboard-title">My Writings</h2>
          <p class="dashboard-subtitle">Manage Writings & Uploads</p>
        </div>
        <div class="dashboard-content">
          <div class="row mt-4">
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-12 my-1">
                    <a class="card card-dashboard-product d-block" href="<?php echo e(route('admin.product.show', ['id' => $file->id ])); ?>">
                        <div class="card-body">
                            <img src="<?php echo e(asset('storage/thumbnails/'.$file->thumbnail)); ?>" alt="" class="w-100 mb-2" />
                            <div class="product-title">
                                <blockquote class="blockquote">

                                    <strong class="mb-2">
                                        <?php echo e(Str::words($file->title, 5, ' ...')); ?>

                                    </strong>
                                    <footer class="blockquote-footer mt-1"><?php echo e($file->author); ?></footer>
                                  </blockquote>
                            </div>
                        </div>
                    </a>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bagitulis-web-uploads\resources\views/pages/admin/products.blade.php ENDPATH**/ ?>